//
//  Food.h
//  DataAccess_Demo
//
//  Created by 戴运鹏 on 2018/6/23.
//  Copyright © 2018年 戴运鹏. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Food : NSObject<NSCoding>
@property (nonatomic,copy)NSString *name;

@end
